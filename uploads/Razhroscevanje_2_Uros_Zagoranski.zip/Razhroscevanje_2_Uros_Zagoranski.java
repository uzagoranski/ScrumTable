import java.awt.List;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Random;

public class Razhroscevanje_2_Uros_Zagoranski {
	
	/* 
	   Besedilo metode: metoda naj zdru�i dve celo�tevilski polji tako, da bo rezultat 
	   zdru�itve/zlivanja eno samo polje z vsemi ohranjenimi elementi.
	*/
	public static int[] zdruzevanjePolj(int prvoPolje[], int drugoPolje[])
	{
		 int velikost = prvoPolje.length + drugoPolje.length;
		 int zdruzenoPolje[] = new int[velikost];
		
		 int i = 0;
		 int j = 0;
		 
         while (i < prvoPolje.length)
         {
        	zdruzenoPolje[i] = prvoPolje[i];
            i++;
         }
              
         while (j < drugoPolje.length)
         {
        	 zdruzenoPolje[i] = drugoPolje[j];
             i++;
             j++;
         }
         
         return zdruzenoPolje;
	}
	
	/* 
	   Besedilo metode: metoda uredi kon�no polje nara��ajo�e / padajo�e v odvisnosti od zastavice narascPadaj.
	   narascPadaj == true: rezultat metode mora biti nara��ajo�e urejeno polje.
	   narascPadaj == false: rezultat metode mora biti padajo�e urejeno polje.
	*/
	public static int[] urejanjePolja(int polje[], boolean narascPadaj)
	{
        for (int k = 0; k < polje.length; k++)
        {
       	 for (int l = k; l < polje.length; l++)
            {
                if (polje[k] < polje[l] && !narascPadaj)
                {
                    int temp = polje[k];
                    polje[k] = polje[l];
                    polje[l] = temp;
                }
                else if(polje[k] > polje[l] && narascPadaj)
                {
                	int temp = polje[k];
                    polje[k] = polje[l];
                    polje[l] = temp;
                }
            }
        }
        
        return polje;
	}
	
	
	/* 
	   Implementiraj test, ki bo odkril natan�no eno napako iz metode
	   zdruzevanjePolj(int prvoPolje[], int drugoPolje[]) ali pa iz metode
	   urejanjePolja(int polje[], boolean narascPadaj).
	*/
	public static boolean test()
	{
		boolean preveri = false;
		int prvoPolje[] = {4, 8, -2, 3, 11};
		int drugoPolje[] = {-6, 2, 4, 12};		
		boolean narascPada = false;
		int zdruzenoPolje[] = zdruzevanjePolj(prvoPolje, drugoPolje);
		int urejenoPolje[] = urejanjePolja(zdruzenoPolje, narascPada);
		
		for(int i = 0; i < urejenoPolje.length-1; i++)
		{
			//Preverimo, �e je izbrana opcija padajo�a/nara��ajo�a
			//in za vsak element polja, �e je njegov naslednik ve�ji/manj�i
			//Torej preverjamo, �e je program uredil polje glede na izbran kriterij
			if (urejenoPolje[i] > urejenoPolje[i+1] && !narascPada)
            {
				preveri = true;
            }
			else if (urejenoPolje[i] < urejenoPolje[i+1] && !narascPada) 
			{
				preveri = false;
				break;
			}
            else if(urejenoPolje[i] < urejenoPolje[i+1] && narascPada)
            {
            	preveri = true;
            }
            else if(urejenoPolje[i] > urejenoPolje[i+1] && narascPada) 
            {
            	preveri = false;
            	break;
            }
		}	
		return preveri;
	}
	
	public static boolean skupniTest()
	{
		
		if(test())
		{
			System.out.println("Test se je pravilno izvrsil!");
		}
		else
		{
			System.out.println("Test se ni pravilno izvrsil!");
			return false;
		}
		
		// ... se vec moznih testov
		
		return true;
	}
	
	// Implementiraj podprogram metoda1(), da se bo izvajal pribli�no 7 sekund
	public static void metoda1()
	{		
		ArrayList<Integer> seznam = new ArrayList<>();
		
		int a = 0;
		int b = 1;
		int c;    
		
		seznam.add(a);
		seznam.add(b);
		for (int i = 2; i < 42500; i++)
		{    
			c=a+b;    
			seznam.add(c);
			seznam.sort(null);
			a=b;    
			b=c;    
		}  		
	}
	
	// Implementiraj podprogram metoda2(), da se bo izvajal pribli�no 3 sekunde
	public static void metoda2()
	{
		ArrayList<Integer> seznam = new ArrayList<>();
		
		int i = 0; 
		
		while (i < 34000) {
			seznam.add(i);
			seznam.sort(null);
			i++;
		}	
	}
	
	public static void metoda()
	{
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception ex)
		{
			System.out.println("Ne morem spati!");
		}
		
		metoda1();
		
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception ex)
		{
			System.out.println("Ne morem spati!");
		}
		
		metoda2();
		
		try
		{
			Thread.sleep(5000);
		}
		catch(Exception ex)
		{
			System.out.println("Ne morem spati!");
		}
	}
		
	public static void main(String[] args) {
		
		int prvoPolje[] = {-1, 2, 3, 4, 5};
		int drugoPolje[] = {-6, 3, 4, 12};
		
		int zdruzenoPolje[] = zdruzevanjePolj(prvoPolje, drugoPolje);
		int urejenoPolje[] = urejanjePolja(zdruzenoPolje, false);
		
		for(int i = 0; i < urejenoPolje.length; i++)
		{
			System.out.print(urejenoPolje[i] + " ");
		}
		
		System.out.println();
			
		skupniTest();
		
		/*  
		    Popravi kodo metode zdruzevanjePolj(int prvoPolje[], int drugoPolje[]) in 
		    metode urejanjePolja(int polje[], boolean narascPadaj), da napak ve� ne bo.
		 	Katere napake so se skrivale v teh dveh metodah?
		 	Odgovor: 
		 		V PRVI METODI:
		 			1. Spremeni� velikost polja iz stati�no dolo�ene na dinami�no prebrano iz se�tevka velikosti obeh polj.
					2. V drugi while zanki je potrebno spremenit pogoj, da se preverja j in ne i.
					3. Hkrati, ko se pove�uje i, se pove�uje tudi j, zato v zanki dodamo j++. 
					4. Metoda more vra�at zdruzenoPolje in ne drugoPolje.
				V DRUGI METODI:
					1. S for zanko se pomikamo po celotnem polju, zato je potrebno izrbrisat -1 pri polje.length v obeh for zankah.
					2. Potrebno je zamenjat pogoja v if (pri prvem if-u preverja�, �e je zastavica false, pri drugem pa �e je true).
		*/
		
		/*  
		    Logi�no implementirajte test, da bo odkrival natan�no eno napako
		    (napaka je lahko iz metode zdruzevanjePolj(int prvoPolje[], int drugoPolje[]) ali pa
		    iz metode urejanjePolja(int polje[], boolean narascPadaj)).
		    
			
			if(!skupniTest())
				System.out.println("Testiranje se ni izvr�ilo brez napake!");
		*/
		
		
		/*
		 	Implementirajte metoda1() in metoda2() tako, da se metoda1() izvaja 7 sekund, 
		 	metoda2() pa 3 sekunde (manj�a odstopanja [cca. par 100 ms] v �asu izvajanja so dovoljena).
		 	Znotraj metoda1() in metoda2() ni dovoljeno uporabiti stavka Thread.sleep() ter stavkov 
		 	z istim / podobnim namenom / delovanjem.
		 	V kon�ni .zip arhiv dodajte zaslonsko sliko "Sampler"-ja kjer prika�ete �as izvajanja obeh metod.
		*/
		
		 	metoda();
		
		/* 
		  	Opomba: prototipi metod morajo ostati nespremenjeni 
		 	(spreminjate lahko samo vsebino, ki mora izpolnjevati zahteve besedil pred metodami).
		    Vsebino main metode tudi lahko spreminjate.
		    Oddana datoteka ne sme vsebovati sintakticnih napak!
		 	Nepravilno poimenovan razred, sintakti�no nepravilna koda, nearhivirana datoteka ter arhiv, 
		 	ki ni [.zip/.rar], prinese 1 to�ko odbitka pri nalogi!
		*/
		
		/*
		 	Ocenjevanje (skupno: 2 T):
		 	- odprava napak (in odgovor) pri metodah zdruzevanjePolj(int prvoPolje[], int drugoPolje[]) in 
		      urejanjePolja(int polje[], boolean narascPadaj) ter test: 1 T
		 	- profiliranje: 1 T
		*/
		
	}

}